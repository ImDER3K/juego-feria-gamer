
import processing.event.*;

// ==================================================
// SUPERVIVENCIA DIGITAL
// Processing - Java Mode
// ==================================================

// ---------------- CONFIGURACION ----------------

final int ANCHO = 1080;
final int ALTO = 600;

final int MENU = 0;
final int CINEMATICA = 1;
final int EXPLORACION = 2;
final int DIALOGO = 3;
final int MINIJUEGO = 4;
final int PAUSA = 5;
final int FINAL = 6;

int estadoActual = MENU;

// ---------------- IMAGENES ----------------

PImage fondoMenu;
PImage mapa;
PImage colisiones;

boolean recursosListos = false;
boolean errorRecursos = false;

// ---------------- JUGADOR ----------------

float jugadorX;
float jugadorY;

float destinoX;
float destinoY;

float velocidad = 3.5;

boolean moviendo = false;

// ---------------- CAMARA ----------------

float zoomActual = 1.0;
float zoomInicial = 1.0;
float zoomFinal = 1.5;

int tiempoCinematica;
int duracionCinematica = 2500;

// ---------------- PUNTOS DEL MAPA ----------------

float[] puntosX = new float[5];
float[] puntosY = new float[5];

String[] nombresPuntos = {
  "Fuente",
  "Biblioteca",
  "Cafeteria",
  "Salon",
  "Zona deportiva"
};

// ---------------- NIEBLA DE GUERRA ----------------

int tamanoCelda = 16;

int columnasNiebla;
int filasNiebla;

boolean[][] mapaDescubierto;

float radioDescubrimiento = 120;

// ---------------- INTERFAZ ----------------

boolean mostrarColisiones = false;

int diaActual = 1;
float horasRestantes = 8;

// ==================================================
// SETUP
// ==================================================

void setup() {

  size(1080, 600, P2D);
  pixelDensity(1);

  surface.setTitle("Supervivencia Digital");

  cargarRecursos();

  if (recursosListos) {

    configurarNiebla();
    configurarPuntos();

    if (!iniciarJugador()) {
      errorRecursos = true;
      recursosListos = false;
    }
  }
}

// ==================================================
// CARGAR RECURSOS
// ==================================================

void cargarRecursos() {

  fondoMenu = loadImage("menu/fondo_menu.jpg");
  mapa = loadImage("mapas/mapa.png");

  // IMPORTANTE: la mascara debe ser PNG.
  colisiones = loadImage("mapas/colisiones.jpg");

  if (fondoMenu == null) {
    println("ERROR: No se encontro fondo_menu.jpg");
    errorRecursos = true;
    return;
  }

  if (mapa == null) {
    println("ERROR: No se encontro mapa.png");
    errorRecursos = true;
    return;
  }

  if (colisiones == null) {
    println("ERROR: No se encontro colisiones.jpg");
    println("Comprueba el nombre y la extension del archivo.");
    errorRecursos = true;
    return;
  }

  mapa.loadPixels();
  colisiones.loadPixels();

  println("--------------------------------");
  println("MAPA: " + mapa.width + " x " + mapa.height);
  println("COLISIONES: " + colisiones.width + " x " + colisiones.height);
  println("--------------------------------");

  // No redimensionamos la mascara.
  // Debe coincidir exactamente con el mapa.

  if (mapa.width != colisiones.width ||
      mapa.height != colisiones.height) {

    println("ERROR: Las dimensiones no coinciden.");
    println("Mapa y colisiones deben tener el mismo tamaño.");

    errorRecursos = true;
    return;
  }

  recursosListos = true;
}

// ==================================================
// CONFIGURAR PUNTOS
// ==================================================

void configurarPuntos() {

  // Puntos provisionales distribuidos por el mapa.
  // El movimiento ya no esta limitado a estos puntos.

  puntosX[0] = mapa.width * 0.50;
  puntosY[0] = mapa.height * 0.30;

  puntosX[1] = mapa.width * 0.25;
  puntosY[1] = mapa.height * 0.45;

  puntosX[2] = mapa.width * 0.70;
  puntosY[2] = mapa.height * 0.45;

  puntosX[3] = mapa.width * 0.45;
  puntosY[3] = mapa.height * 0.70;

  puntosX[4] = mapa.width * 0.75;
  puntosY[4] = mapa.height * 0.75;
}

// ==================================================
// CONFIGURAR NIEBLA
// ==================================================

void configurarNiebla() {

  columnasNiebla = ceil(mapa.width / (float)tamanoCelda);
  filasNiebla = ceil(mapa.height / (float)tamanoCelda);

  mapaDescubierto = new boolean[columnasNiebla][filasNiebla];

  for (int x = 0; x < columnasNiebla; x++) {
    for (int y = 0; y < filasNiebla; y++) {
      mapaDescubierto[x][y] = false;
    }
  }
}

// ==================================================
// INICIAR JUGADOR
// ==================================================

boolean iniciarJugador() {

  int mejorX = -1;
  int mejorY = -1;

  float menorDistancia = Float.MAX_VALUE;

  float centroX = mapa.width / 2.0;
  float centroY = mapa.height / 2.0;

  // Buscar un pixel verde con espacio alrededor.
  // Asi evitamos colocar al jugador en un borde.

  for (int y = 6; y < colisiones.height - 6; y++) {

    for (int x = 6; x < colisiones.width - 6; x++) {

      if (!esPixelVerde(x, y)) {
        continue;
      }

      boolean espacioValido = true;

      for (int dy = -5; dy <= 5; dy++) {

        for (int dx = -5; dx <= 5; dx++) {

          if (!esPixelVerde(x + dx, y + dy)) {
            espacioValido = false;
            break;
          }
        }

        if (!espacioValido) {
          break;
        }
      }

      if (espacioValido) {

        float distancia = dist(
          centroX,
          centroY,
          x,
          y
        );

        if (distancia < menorDistancia) {

          menorDistancia = distancia;

          mejorX = x;
          mejorY = y;
        }
      }
    }
  }

  if (mejorX == -1) {

    println("ERROR: No se encontro una zona verde suficientemente amplia.");
    return false;
  }

  // Como ambas imagenes tienen el mismo tamaño,
  // usamos las coordenadas directamente.

  jugadorX = mejorX;
  jugadorY = mejorY;

  destinoX = jugadorX;
  destinoY = jugadorY;

  moviendo = false;

  println("--------------------------------");
  println("JUGADOR INICIADO");
  println("X: " + jugadorX);
  println("Y: " + jugadorY);
  println("Pixel verde: " + esPixelVerde(mejorX, mejorY));
  println("--------------------------------");

  actualizarDescubrimiento();

  return true;
}

// ==================================================
// DETECTAR ZONAS TRANSITABLES
// ==================================================

boolean esPixelVerde(int px, int py) {

  if (px < 0 || py < 0 ||
      px >= colisiones.width ||
      py >= colisiones.height) {

    return false;
  }

  color c = colisiones.pixels[py * colisiones.width + px];

  float r = red(c);
  float g = green(c);
  float b = blue(c);

  // Verde puro RGB (0,255,0).
  // No se aceptan jardines ni tonos verdes parecidos.

  return r == 0 && g == 255 && b == 0;
}

// ==================================================
// COMPROBAR COLISION
// ==================================================

boolean esZonaVerde(float x, float y) {

  int px = round(x);
  int py = round(y);

  return esPixelVerde(px, py);
}

// ==================================================
// DRAW PRINCIPAL
// ==================================================

void draw() {

  background(20);

  if (!recursosListos) {

    dibujarError();
    return;
  }

  switch(estadoActual) {

  case MENU:
    dibujarMenu();
    break;

  case CINEMATICA:
    dibujarCinematica();
    break;

  case EXPLORACION:
    actualizarExploracion();
    dibujarExploracion();
    break;

  case DIALOGO:
    dibujarExploracion();
    dibujarDialogo();
    break;

  case MINIJUEGO:
    dibujarMinijuego();
    break;

  case PAUSA:
    dibujarExploracion();
    dibujarPausa();
    break;

  case FINAL:
    dibujarFinal();
    break;
  }
}

// ==================================================
// ERROR DE RECURSOS
// ==================================================

void dibujarError() {

  background(30);

  fill(255);
  textAlign(CENTER, CENTER);

  textSize(25);
  text("NO SE PUDIERON CARGAR LOS RECURSOS", width/2, 220);

  textSize(15);
  text(
    "Revisa la carpeta data y la consola de Processing.",
    width/2,
    270
  );

  text(
    "Necesitas mapa.png y colisiones.png del mismo tamaño.",
    width/2,
    300
  );
}

// ==================================================
// MENU
// ==================================================

void dibujarMenu() {

  imageMode(CORNER);
  image(fondoMenu, 0, 0, width, height);

  fill(255);
  textAlign(LEFT, CENTER);

  textSize(40);
  text("SUPERVIVENCIA", 55, 90);
  text("DIGITAL", 55, 135);

  dibujarBoton("JUGAR", 55, 230, 230, 48);
  dibujarBoton("CONTINUAR", 55, 290, 230, 48);
  dibujarBoton("COMO JUGAR", 55, 350, 230, 48);
  dibujarBoton("CREDITOS", 55, 410, 230, 48);
  dibujarBoton("SALIR", 55, 470, 230, 48);
}

// ==================================================
// BOTONES
// ==================================================

void dibujarBoton(String texto, float x, float y, float w, float h) {

  boolean encima =
    mouseX >= x &&
    mouseX <= x + w &&
    mouseY >= y &&
    mouseY <= y + h;

  if (encima) {
    fill(80, 220, 140);
  } else {
    fill(35, 35, 45, 230);
  }

  stroke(255);
  strokeWeight(2);

  rect(x, y, w, h, 12);

  noStroke();
  fill(255);

  textAlign(CENTER, CENTER);
  textSize(18);

  text(texto, x + w/2, y + h/2);
}

// ==================================================
// CINEMATICA
// ==================================================

void iniciarCinematica() {

  estadoActual = CINEMATICA;

  tiempoCinematica = millis();

  zoomActual = zoomInicial;
}

void dibujarCinematica() {

  float progreso =
    constrain(
      (millis() - tiempoCinematica) / (float)duracionCinematica,
      0,
      1
    );

  // Animacion suave del zoom.

  float suavizado = progreso * progreso * (3 - 2 * progreso);

  zoomActual = lerp(
    zoomInicial,
    zoomFinal,
    suavizado
  );

  dibujarMapa();

  fill(255);
  textAlign(CENTER, CENTER);
  textSize(20);

  text("Preparando el campus...", width/2, height - 45);

  if (progreso >= 1) {

    estadoActual = EXPLORACION;

    zoomActual = zoomFinal;
  }
}

// ==================================================
// EXPLORACION
// ==================================================

void actualizarExploracion() {

  moverJugador();

  actualizarDescubrimiento();
}

void dibujarExploracion() {

  dibujarMapa();

  dibujarHUD();

  if (mostrarColisiones) {
    dibujarMascaraDepuracion();
  }
}

// ==================================================
// DIBUJAR MAPA Y CAMARA
// ==================================================

void dibujarMapa() {

  pushMatrix();

  translate(width/2, height/2);

  scale(zoomActual);

  // La camara sigue al jugador.

  imageMode(CORNER);

  image(
    mapa,
    -jugadorX,
    -jugadorY
  );

  // Niebla de guerra.

  dibujarNiebla();

  // Puntos de interes.

  dibujarPuntos();

  popMatrix();

  // Jugador en el centro de la pantalla.

  dibujarJugador();
}

// ==================================================
// DIBUJAR JUGADOR
// ==================================================

void dibujarJugador() {

  float centroX = width/2;
  float centroY = height/2;

  // Sombra.

  noStroke();
  fill(0, 100);

  ellipse(
    centroX,
    centroY + 9,
    25,
    12
  );

  // Cuerpo.

  fill(255, 190, 50);

  ellipse(
    centroX,
    centroY,
    25,
    25
  );

  // Centro.

  fill(255);

  ellipse(
    centroX,
    centroY,
    9,
    9
  );

  // Borde.

  noFill();
  stroke(30);
  strokeWeight(2);

  ellipse(
    centroX,
    centroY,
    25,
    25
  );

  noStroke();
}

// ==================================================
// MOVIMIENTO DEL JUGADOR
// ==================================================

void moverJugador() {

  if (!moviendo) {
    return;
  }

  float dx = destinoX - jugadorX;
  float dy = destinoY - jugadorY;

  float distancia = sqrt(dx*dx + dy*dy);

  if (distancia < 1) {

    jugadorX = destinoX;
    jugadorY = destinoY;

    moviendo = false;
    return;
  }

  float paso = min(velocidad, distancia);

  float nuevoX = jugadorX + (dx/distancia) * paso;
  float nuevoY = jugadorY + (dy/distancia) * paso;

  // Revisamos varios puntos entre la posicion actual
  // y la nueva para evitar atravesar paredes.

  float distanciaPaso = dist(
    jugadorX,
    jugadorY,
    nuevoX,
    nuevoY
  );

  int muestras = max(1, ceil(distanciaPaso / 2.0));

  for (int i = 1; i <= muestras; i++) {

    float t = i / (float)muestras;

    float comprobarX = lerp(jugadorX, nuevoX, t);
    float comprobarY = lerp(jugadorY, nuevoY, t);

    if (!esZonaVerde(comprobarX, comprobarY)) {

      moviendo = false;
      return;
    }
  }

  jugadorX = nuevoX;
  jugadorY = nuevoY;

  if (distancia <= paso) {
    moviendo = false;
  }
}

// ==================================================
// NIEBLA DE GUERRA
// ==================================================

void actualizarDescubrimiento() {

  int centroCeldaX = int(jugadorX / tamanoCelda);
  int centroCeldaY = int(jugadorY / tamanoCelda);

  int rango = ceil(radioDescubrimiento / tamanoCelda);

  for (int x = centroCeldaX - rango;
       x <= centroCeldaX + rango;
       x++) {

    for (int y = centroCeldaY - rango;
         y <= centroCeldaY + rango;
         y++) {

      if (x < 0 || y < 0 ||
          x >= columnasNiebla ||
          y >= filasNiebla) {

        continue;
      }

      float mundoX = x * tamanoCelda + tamanoCelda/2;
      float mundoY = y * tamanoCelda + tamanoCelda/2;

      float distancia = dist(
        jugadorX,
        jugadorY,
        mundoX,
        mundoY
      );

      if (distancia <= radioDescubrimiento) {
        mapaDescubierto[x][y] = true;
      }
    }
  }
}

void dibujarNiebla() {

  noStroke();

  fill(0, 225);

  for (int x = 0; x < columnasNiebla; x++) {

    for (int y = 0; y < filasNiebla; y++) {

      if (!mapaDescubierto[x][y]) {

        rect(
          x * tamanoCelda - jugadorX,
          y * tamanoCelda - jugadorY,
          tamanoCelda + 1,
          tamanoCelda + 1
        );
      }
    }
  }
}

// ==================================================
// PUNTOS DE INTERES
// ==================================================

void dibujarPuntos() {

  textAlign(CENTER, CENTER);
  textSize(12);

  for (int i = 0; i < puntosX.length; i++) {

    float px = puntosX[i] - jugadorX;
    float py = puntosY[i] - jugadorY;

    fill(255, 220, 80);
    noStroke();

    ellipse(px, py, 14, 14);

    fill(255);
    text(
      nombresPuntos[i],
      px,
      py - 17
    );
  }
}

// ==================================================
// HUD
// ==================================================

void dibujarHUD() {

  // Fondo superior.

  noStroke();
  fill(20, 20, 30, 220);

  rect(0, 0, width, 65);

  fill(255);

  textAlign(LEFT, CENTER);

  textSize(18);
  text("DIA " + diaActual, 25, 25);

  textSize(14);
  text("8 HORAS", 25, 47);

  // Estado del jugador.

  textAlign(RIGHT, CENTER);

  text(
    "X: " + int(jugadorX) + "   Y: " + int(jugadorY),
    width - 25,
    25
  );

  text(
    "Clic para moverte | ESC para pausar | M para ver colisiones",
    width - 25,
    47
  );
}

// ==================================================
// VISUALIZAR MASCARA DE COLISIONES
// ==================================================

void dibujarMascaraDepuracion() {

  pushMatrix();

  translate(width/2, height/2);

  scale(zoomActual);

  tint(255, 120);

  image(
    colisiones,
    -jugadorX,
    -jugadorY
  );

  noTint();

  popMatrix();

  // Panel de informacion.

  fill(0, 200);
  noStroke();

  rect(15, 80, 260, 75, 8);

  fill(255);
  textAlign(LEFT, CENTER);
  textSize(13);

  text(
    "Jugador: " + int(jugadorX) + ", " + int(jugadorY),
    25,
    100
  );

  text(
    "Zona verde: " + esZonaVerde(jugadorX, jugadorY),
    25,
    120
  );

  color c = colisiones.pixels[
    round(jugadorY) * colisiones.width + round(jugadorX)
  ];

  text(
    "RGB: " + int(red(c)) + ", " +
    int(green(c)) + ", " + int(blue(c)),
    25,
    140
  );
}

// ==================================================
// DIALOGO
// ==================================================

void dibujarDialogo() {

  noStroke();
  fill(0, 220);

  rect(0, height - 150, width, 150);

  fill(255);
  textAlign(LEFT, CENTER);

  textSize(20);
  text("Un compañero quiere hablar contigo...", 40, height - 100);

  textSize(14);
  text("Presiona ENTER para continuar.", 40, height - 60);
}

// ==================================================
// MINIJUEGO
// ==================================================

void dibujarMinijuego() {

  background(35, 45, 60);

  fill(255);
  textAlign(CENTER, CENTER);

  textSize(30);
  text("MINIJUEGO", width/2, height/2 - 30);

  textSize(16);
  text("Esta pantalla se desarrollara posteriormente.", width/2, height/2 + 15);

  text("Presiona ESC para pausar.", width/2, height/2 + 50);
}

// ==================================================
// PAUSA
// ==================================================

void dibujarPausa() {

  noStroke();
  fill(0, 190);

  rect(0, 0, width, height);

  fill(255);
  textAlign(CENTER, CENTER);

  textSize(38);
  text("PAUSA", width/2, 190);

  dibujarBoton("CONTINUAR", width/2 - 115, 250, 230, 45);
  dibujarBoton("VOLVER AL MENU", width/2 - 115, 310, 230, 45);
}

// ==================================================
// FINAL
// ==================================================

void dibujarFinal() {

  background(25, 30, 40);

  fill(255);
  textAlign(CENTER, CENTER);

  textSize(38);
  text("FIN DE LA PARTIDA", width/2, height/2 - 30);

  textSize(18);
  text("Gracias por jugar Supervivencia Digital", width/2, height/2 + 25);

  dibujarBoton("VOLVER AL MENU", width/2 - 115, height/2 + 80, 230, 45);
}

// ==================================================
// CONVERTIR CLIC A COORDENADAS DEL MAPA
// ==================================================

float pantallaAMapaX(float pantallaX) {

  return (pantallaX - width/2) / zoomActual + jugadorX;
}

float pantallaAMapaY(float pantallaY) {

  return (pantallaY - height/2) / zoomActual + jugadorY;
}

// ==================================================
// MOUSE PRESSED
// ==================================================

void mousePressed() {

  if (!recursosListos) {
    return;
  }

  if (estadoActual == MENU) {

    if (mouseX >= 55 && mouseX <= 285) {

      if (mouseY >= 230 && mouseY <= 278) {

        iniciarCinematica();
      }
    }

    return;
  }

  if (estadoActual == EXPLORACION) {

    float nuevoDestinoX = pantallaAMapaX(mouseX);
    float nuevoDestinoY = pantallaAMapaY(mouseY);

    // Evitamos destinos fuera del mapa.

    if (nuevoDestinoX < 0 ||
        nuevoDestinoY < 0 ||
        nuevoDestinoX >= mapa.width ||
        nuevoDestinoY >= mapa.height) {

      return;
    }

    // Solo se acepta un destino verde.

    if (esZonaVerde(nuevoDestinoX, nuevoDestinoY)) {

      destinoX = nuevoDestinoX;
      destinoY = nuevoDestinoY;

      moviendo = true;

    } else {

      println("Destino bloqueado: zona negra.");
    }

    return;
  }

  if (estadoActual == PAUSA) {

    if (mouseX >= width/2 - 115 &&
        mouseX <= width/2 + 115) {

      if (mouseY >= 250 && mouseY <= 295) {

        estadoActual = EXPLORACION;
        return;
      }

      if (mouseY >= 310 && mouseY <= 355) {

        estadoActual = MENU;
        return;
      }
    }
  }

  if (estadoActual == FINAL) {

    if (mouseY >= height/2 + 80 &&
        mouseY <= height/2 + 125) {

      estadoActual = MENU;
    }
  }
}

// ==================================================
// TECLADO
// ==================================================

void keyPressed() {

  if (key == ESC) {

    key = 0;

    if (estadoActual == EXPLORACION ||
        estadoActual == DIALOGO ||
        estadoActual == MINIJUEGO) {

      estadoActual = PAUSA;

    } else if (estadoActual == PAUSA) {

      estadoActual = EXPLORACION;
    }

    return;
  }

  if (key == 'm' || key == 'M') {

    mostrarColisiones = !mostrarColisiones;
  }

  if (estadoActual == DIALOGO && key == ENTER) {

    estadoActual = EXPLORACION;
  }
}
